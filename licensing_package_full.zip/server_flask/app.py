from flask import Flask, request, jsonify, render_template, redirect, url_for
import jwt, time, sqlite3, os
from functools import wraps
import firebase_admin
from firebase_admin import credentials, messaging

# CONFIG - replace with your generated RSA keys
PRIVATE_KEY_FILE = "private.pem"
PUBLIC_KEY_FILE = "public.pem"
DB_FILE = "licenses.db"

with open(PRIVATE_KEY_FILE, "r") as f:
    PRIVATE_KEY = f.read()
with open(PUBLIC_KEY_FILE, "r") as f:
    PUBLIC_KEY = f.read()

cred = credentials.Certificate("firebase_service_account.json")
firebase_admin.initialize_app(cred)

app = Flask(__name__)
ADMIN_KEY = os.environ.get("ADMIN_KEY", "change_me")

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS licenses (
        id TEXT PRIMARY KEY,
        device_id TEXT,
        status TEXT,
        created INTEGER,
        expires INTEGER
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT,
        license_id TEXT,
        fcm_token TEXT,
        last_seen INTEGER,
        token TEXT
    )""")
    conn.commit()
    conn.close()

init_db()

def send_revoke_push(fcm_token, license_id):
    if not fcm_token:
        return False
    message = messaging.Message(
        data={"type":"revoke","licenseId":license_id},
        token=fcm_token
    )
    try:
        resp = messaging.send(message)
        print("Sent:", resp)
        return True
    except Exception as e:
        print("FCM error:", e)
        return False

@app.route("/activate", methods=["POST"])
def activate():
    data = request.json or {}
    license_id = data.get("licenseId")
    device_id = data.get("deviceId")
    fcm_token = data.get("fcmToken")
    if not license_id or not device_id:
        return jsonify({"error":"licenseId and deviceId required"}), 400
    now = int(time.time())
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO licenses (id, device_id, status, created, expires) VALUES (?,?,?,?,?)",
                (license_id, device_id, "active", now, now + 60*60*24*365))
    cur.execute("INSERT OR REPLACE INTO devices (device_id, license_id, fcm_token, last_seen) VALUES (?,?,?,?)",
                (device_id, license_id, fcm_token, now))
    conn.commit()
    conn.close()
    payload = {"licenseId": license_id, "deviceId": device_id, "exp": now + 60*60*24, "iat": now, "revoked": False}
    token = jwt.encode(payload, PRIVATE_KEY, algorithm="RS256")
    return jsonify({"token": token, "publicKey": PUBLIC_KEY})

@app.route("/admin/devices")
def admin_devices():
    if request.args.get("admin_key") != ADMIN_KEY:
        return "unauthorized", 401
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT d.id,d.device_id,d.license_id,d.fcm_token,d.last_seen,l.status FROM devices d LEFT JOIN licenses l ON d.license_id=l.id")
    rows = cur.fetchall()
    conn.close()
    return render_template("admin_devices.html", devices=rows)

@app.route("/admin/revoke", methods=["POST"])
def admin_revoke():
    if request.form.get("admin_key") != ADMIN_KEY:
        return "unauthorized", 401
    license_id = request.form.get("license_id")
    if not license_id:
        return "license_id required", 400
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("UPDATE licenses SET status='revoked' WHERE id=?", (license_id,))
    cur.execute("SELECT fcm_token FROM devices WHERE license_id=?", (license_id,))
    tokens = [r[0] for r in cur.fetchall() if r[0]]
    conn.commit()
    conn.close()
    for t in tokens:
        send_revoke_push(t, license_id)
    return redirect(url_for('admin_devices', admin_key=ADMIN_KEY))

@app.route("/validate", methods=["POST"])
def validate():
    data = request.json or {}
    token = data.get("token")
    if not token:
        return jsonify({"error":"token required"}), 400
    try:
        payload = jwt.decode(token, PUBLIC_KEY, algorithms=["RS256"])
    except Exception as e:
        return jsonify({"status":"invalid", "error": str(e)}), 400
    license_id = payload.get("licenseId")
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT status FROM licenses WHERE id=?", (license_id,))
    row = cur.fetchone()
    conn.close()
    status = row[0] if row else "revoked"
    return jsonify({"status": status})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
